<!--<div class="footer">
    <div class="container">


        <b class="copyright">&copy; <?php /*echo date('Y');*/?> T-Care Plus HomeCare Dublin. </b> All rights reserved.
    </div>
</div>-->
<script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
<script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
<script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>


<footer>
    <div class="copyright-info">
        <p class="pull-right">&copy; <?php echo date('Y');?> T-Care Plus HomeCare Dublin. </b> All rights reserved.
        </p>
    </div>
    <div class="clearfix"></div>
</footer>


