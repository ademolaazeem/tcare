<div class="navbar nav_title" style="border: 0;">
    <a href="carer_dashboard.php" class="site_title"><i class="fa fa-paw"></i> <span>Carer Home</span></a>
</div>
<div class="clearfix"></div>