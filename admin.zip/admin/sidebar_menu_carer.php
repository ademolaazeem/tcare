<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">

    <div class="menu_section">
        <h3>General</h3>
        <ul class="nav side-menu">
            <li><a><i class="fa fa-home"></i> Home <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu" style="display: none">
                    <li><a href="index.php">Dashboard</a>
                    </li>

                </ul>
            </li>
            <li><a><i class="fa fa-edit"></i> Carer <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu" style="display: none">
                   <!-- <li><a href="form.html">Add New Carer</a>
                    </li>-->
                    <li><a href="show_manage_carer.php">Edit Carer</a>
                    </li>
                    <li><a href="form_validation.html">Assign Carer</a>
                    </li>
                    <li><a href="form_validation.html">Manage Carer Holiday</a>
                    </li>

                </ul>
            </li>

            <li><a><i class="fa fa-edit"></i> Patient <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu" style="display: none">
                    <li><a href="form.html">Add New Patient</a>
                    </li>
                    <li><a href="form_advanced.html">Edit Patient</a>
                    </li>
                </ul>
            </li>
            <li><a><i class="fa fa-edit"></i> Cover <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu" style="display: none">
                    <li><a href="form.html">Ask for Cover</a>
                    </li>
                    <li><a href="form_advanced.html">Assign Cover</a>
                    </li>
                </ul>
            </li>

            <li><a><i class="fa fa-edit"></i> Report <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu" style="display: none">
                    <li><a href="form.html">Carer Schedule</a>
                    </li>
                    <li><a href="form_advanced.html">Granted Holidays</a>
                    </li>
                    <li><a href="form_advanced.html">Rejected Holidays</a>
                    </li>

                </ul>
            </li>

        </ul>
    </div>


</div>