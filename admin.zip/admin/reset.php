﻿<?php //error_reporting(0);
include_once('CommonClass/common.php');
include_once('CommonClass/ClassManager.php');
$db = new DBConnections();
$adm = new AdminClassController();

?>
<?php

// First we execute our CommonClass code to connection to the database and start the session


?>

<!DOCTYPE html>
<html lang="en">


<?php
include_once('head.php');
?>






<body class="nav-md">

  <div class="container body">


    <div class="main_container">

      <div class="col-md-3 left_col">
        <div class="left_col scroll-view">
            <?php include_once('nav_title.php') ?>

            <!-- menu prile quick info -->
            <?php include_once('menu_prile.php') ?>
            <!-- /menu prile quick info -->

          <br />

            <!-- sidebar menu -->
            <?php include_once('sidebar_menu.php') ?>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <?php include_once('footer_buttons.php'); ?>
            <!-- /menu footer buttons -->
        </div>
      </div>

      <!-- top navigation -->
      <?php include_once('top_nav.php'); ?>
      <!-- /top navigation -->

      <!-- page content -->
      <div class="right_col" role="main">
        <div class="">

          <div class="page-title">
            <div class="title_left">
              <h3>Reset Password</h3>
            </div>

          </div>
          <div class="clearfix"></div>
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_content">
                    <br />

                    <?php if(isset($msg)) echo $msg; ?>
                                       
                      <?php
                      //file reset.php
                      //title:Build your own Forgot Password PHP Script
                      //session_start();
                      $token=$_GET['token'];

                     // if(!isset($_POST['password'])){
                          $q="select email from tokens where token='".$token."' and used=0";
                          $r=mysql_query($q);
                          while($row=mysql_fetch_array($r))
                          {
                              $email=$row['email'];
                          }
                          If ($email!=''){
                              $_SESSION['email']=$email;

                          //added this
                              $pass=mysql_real_escape_string($_POST['password']);
                              $cpass=mysql_real_escape_string($_POST['cpassword']);
                              //$pass=$_POST['password'];
                              $email=$_SESSION['email'];
                              //if(!isset($pass)){
                              echo '<form name="frmReset" method="post" action="" autocomplete="off">
                          <fieldset>
                              <br /><br />
                              <legend style="color: #00A800">Provide your registered email</legend>
                                <table>

                                  <tr>
                                      <td>&nbsp;</td>
                                      <td>&nbsp;</td>
                                      <td>&nbsp;</td>
                                      <td>&nbsp;</td>
                                  </tr>
                                  <tr>
                                      <td>&nbsp;</td>
                                      <td><label for="login">Password: </label></td>
                                      <td><input type="password" id="login" name="password" size="30" class="mO"/></td>
                                      <td>&nbsp;</td>
                                  </tr>
                                  <tr>
                                      <td>&nbsp;</td>
                                      <td><label for="login">Confirm Password: </label></td>
                                      <td><input type="password" id="login" name="cpassword" size="30" class="mO"/></td>
                                      <td>&nbsp;</td>
                                  </tr>
                                  <tr>
                                      <td>&nbsp;</td>
                                      <td>&nbsp;</td>
                                      <td><input type="submit" style="margin: 10px 0 0 5px;" class="buttonReset" name="btnResetPassword" value="Reset My Password"/></td>
                                      <td>&nbsp;</td>
                                  </tr>
                                  <tr>
                                      <td>&nbsp;</td>
                                      <td>&nbsp;</td>
                                      <td>&nbsp;</td>
                                      <td>&nbsp;</td>
                                  </tr>
                              </table>

                          </fieldset>
                      </form>';
                              //}

                              if(isset($_POST['password'])&& isset($_SESSION['email']))
                              {

                                  if( strlen($_POST['password']) < 8 ) {
                                      echo '<strong><div style= "font-size: medium; color:orangered; align-content:center">Password too short!</div></strong>';
                                  }

                                  else if( strlen($_POST['password']) > 20 ) {

                                      echo '<strong><div style= "font-size: medium; color:orangered; align-content:center">Password too long!</div></strong>';
                                  }

                                  else if( !preg_match("#[0-9]+#", $_POST['password']) ) {
                                      echo '<strong><div style= "font-size: medium; color:orangered; align-content:center">Password must include at least one number!</div></strong>';

                                  }


                                  else if( !preg_match("#[a-z]+#", $_POST['password']) ) {
                                      echo '<strong><div style= "font-size: medium; color:orangered; align-content:center">Password must include at least one letter!</div></strong>';
                                  }


                                  else if( !preg_match("#[A-Z]+#", $_POST['password']) ) {
                                      echo '<strong><div style= "font-size: medium; color:orangered; align-content:center">Password must include at least one CAPS!</div></strong>';
                                  }
                                  /** if( !preg_match("#\W+#", $password) ) {
                                  $error .= "Password must include at least one symbol!";
                                  }*/
                                  //
                                  else if($_POST['password'] != $_POST['cpassword']){

                                      echo '<strong><div style= "font-size: medium; color:orangered; align-content:center">Please make sure your password are match!</div></strong>';
                                  }
                                  else{


                                  $q="update tbl_users set password='".sha1($pass)."' where email='".$email."'";
                                  $r=mysql_query($q);
                                  if($r)mysql_query("update tokens set used=1 where token='".$token."'");
                                  echo '<strong><div style= "font-size: medium; color:green; align-content:center";>Your password is changed successfully!</div></strong>';

                                  if(!$r)
                                      echo '<strong><div style= "font-size: medium; color:orangered; align-content:center">An error occurred from database!</div></strong>';
                                  }

                              }

                              //end added this





                          }
                          else
                              echo '<strong><div style= "font-size: medium; color:orangered; align-content:center">Invalid link or Password already changed!</div></strong>';

                     // }


                      ?>



				 </div>
              </div>
            </div>
          </div>






        </div>
        <!-- /page content -->

        <!-- footer content -->
      <?php include_once('footer.php'); ?>
        <!-- /footer content -->

      </div>

    </div>
  </div>

  <div id="custom_notifications" class="custom-notifications dsp_none">
    <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
    </ul>
    <div class="clearfix"></div>
    <div id="notif-group" class="tabbed_notifications"></div>
  </div>

  <script src="js/bootstrap.min.js"></script>

  <!-- bootstrap progress js -->
  <script src="js/progressbar/bootstrap-progressbar.min.js"></script>
  <script src="js/nicescroll/jquery.nicescroll.min.js"></script>
  <!-- icheck -->
  <script src="js/icheck/icheck.min.js"></script>
  <!-- tags -->
  <script src="js/tags/jquery.tagsinput.min.js"></script>
  <!-- switchery -->
  <script src="js/switchery/switchery.min.js"></script>
  <!-- daterangepicker -->
  <script type="text/javascript" src="js/moment/moment.min.js"></script>
  <script type="text/javascript" src="js/datepicker/daterangepicker.js"></script>
  <!-- richtext editor -->
  <script src="js/editor/bootstrap-wysiwyg.js"></script>
  <script src="js/editor/external/jquery.hotkeys.js"></script>
  <script src="js/editor/external/google-code-prettify/prettify.js"></script>
  <!-- select2 -->
  <script src="js/select/select2.full.js"></script>
  <!-- form validation -->
  <script type="text/javascript" src="js/parsley/parsley.min.js"></script>
  <!-- textarea resize -->
  <script src="js/textarea/autosize.min.js"></script>
  <script>
    autosize($('.resizable_textarea'));
  </script>
  <!-- Autocomplete -->
  <script type="text/javascript" src="js/autocomplete/countries.js"></script>
  <script src="js/autocomplete/jquery.autocomplete.js"></script>
  <!-- pace -->
  <script src="js/pace/pace.min.js"></script>
  <script type="text/javascript">
    $(function() {
      'use strict';
      var countriesArray = $.map(countries, function(value, key) {
        return {
          value: value,
          data: key
        };
      });
      // Initialize autocomplete with custom appendTo:
      $('#autocomplete-custom-append').autocomplete({
        lookup: countriesArray,
        appendTo: '#autocomplete-container'
      });
    });
  </script>
  <script src="js/custom.js"></script>


  <!-- select2 -->
  <script>
    $(document).ready(function() {
      $(".select2_single").select2({
        placeholder: "Select a state",
        allowClear: true
      });
      $(".select2_group").select2({});
      $(".select2_multiple").select2({
        maximumSelectionLength: 4,
        placeholder: "With Max Selection limit 4",
        allowClear: true
      });
    });
  </script>
  <!-- /select2 -->
  <!-- input tags -->
  <script>
    function onAddTag(tag) {
      alert("Added a tag: " + tag);
    }

    function onRemoveTag(tag) {
      alert("Removed a tag: " + tag);
    }

    function onChangeTag(input, tag) {
      alert("Changed a tag: " + tag);
    }

    $(function() {
      $('#tags_1').tagsInput({
        width: 'auto'
      });
    });
  </script>
  <!-- /input tags -->
  <!-- form validation -->
  <script type="text/javascript">
    $(document).ready(function() {
      $.listen('parsley:field:validate', function() {
        validateFront();
      });
      $('#demo-form .btn').on('click', function() {
        $('#demo-form').parsley().validate();
        validateFront();
      });
      var validateFront = function() {
        if (true === $('#demo-form').parsley().isValid()) {
          $('.bs-callout-info').removeClass('hidden');
          $('.bs-callout-warning').addClass('hidden');
        } else {
          $('.bs-callout-info').addClass('hidden');
          $('.bs-callout-warning').removeClass('hidden');
        }
      };
    });

    $(document).ready(function() {
      $.listen('parsley:field:validate', function() {
        validateFront();
      });
      $('#demo-form2 .btn').on('click', function() {
        $('#demo-form2').parsley().validate();
        validateFront();
      });
      var validateFront = function() {
        if (true === $('#demo-form2').parsley().isValid()) {
          $('.bs-callout-info').removeClass('hidden');
          $('.bs-callout-warning').addClass('hidden');
        } else {
          $('.bs-callout-info').addClass('hidden');
          $('.bs-callout-warning').removeClass('hidden');
        }
      };
    });
    try {
      hljs.initHighlightingOnLoad();
    } catch (err) {}
  </script>
  <!-- /form validation -->
  <!-- editor -->
  <script>
    $(document).ready(function() {
      $('.xcxc').click(function() {
        $('#descr').val($('#editor').html());
      });
    });

    $(function() {
      function initToolbarBootstrapBindings() {
        var fonts = ['Serif', 'Sans', 'Arial', 'Arial Black', 'Courier',
            'Courier New', 'Comic Sans MS', 'Helvetica', 'Impact', 'Lucida Grande', 'Lucida Sans', 'Tahoma', 'Times',
            'Times New Roman', 'Verdana'
          ],
          fontTarget = $('[title=Font]').siblings('.dropdown-menu');
        $.each(fonts, function(idx, fontName) {
          fontTarget.append($('<li><a data-edit="fontName ' + fontName + '" style="font-family:\'' + fontName + '\'">' + fontName + '</a></li>'));
        });
        $('a[title]').tooltip({
          container: 'body'
        });
        $('.dropdown-menu input').click(function() {
            return false;
          })
          .change(function() {
            $(this).parent('.dropdown-menu').siblings('.dropdown-toggle').dropdown('toggle');
          })
          .keydown('esc', function() {
            this.value = '';
            $(this).change();
          });

        $('[data-role=magic-overlay]').each(function() {
          var overlay = $(this),
            target = $(overlay.data('target'));
          overlay.css('opacity', 0).css('position', 'absolute').offset(target.offset()).width(target.outerWidth()).height(target.outerHeight());
        });
        if ("onwebkitspeechchange" in document.createElement("input")) {
          var editorOffset = $('#editor').offset();
          $('#voiceBtn').css('position', 'absolute').offset({
            top: editorOffset.top,
            left: editorOffset.left + $('#editor').innerWidth() - 35
          });
        } else {
          $('#voiceBtn').hide();
        }
      };

      function showErrorAlert(reason, detail) {
        var msg = '';
        if (reason === 'unsupported-file-type') {
          msg = "Unsupported format " + detail;
        } else {
          console.log("error uploading file", reason, detail);
        }
        $('<div class="alert"> <button type="button" class="close" data-dismiss="alert">&times;</button>' +
          '<strong>File upload error</strong> ' + msg + ' </div>').prependTo('#alerts');
      };
      initToolbarBootstrapBindings();
      $('#editor').wysiwyg({
        fileUploadError: showErrorAlert
      });
      window.prettyPrint && prettyPrint();
    });
  </script>
  <!-- /editor -->

<!--Wickedpicker-->
  <!-- jquery-1.11.3.min.js-->



  <script type="text/javascript">
      $(document).ready(function()
      {
          $('#date').bootstrapMaterialDatePicker
          ({
              time: false,
              clearButton: true
          });

          $('#fromtime').bootstrapMaterialDatePicker
          ({
              date: false,
              shortTime: false,
              format: 'HH:mm'
          });

          $('#totime').bootstrapMaterialDatePicker
          ({
              date: false,
              shortTime: false,
              format: 'HH:mm'
          });
//date-format
          $('#date-format').bootstrapMaterialDatePicker
          ({
              format: 'dddd DD MMMM YYYY - HH:mm'
          });
          $('#date-format1').bootstrapMaterialDatePicker
          ({
              format: 'dddd DD MMMM YYYY - HH:mm'
          });
          $('#date-fr').bootstrapMaterialDatePicker
          ({
              format: 'DD/MM/YYYY HH:mm',
              lang: 'fr',
              weekStart: 1,
              cancelText : 'ANNULER',
              nowButton : true,
              switchOnClick : true
          });

          $('#date-end').bootstrapMaterialDatePicker
          ({
              weekStart: 0, format: 'DD/MM/YYYY HH:mm'
          });
          $('#date-start').bootstrapMaterialDatePicker
          ({
              weekStart: 0, format: 'DD/MM/YYYY HH:mm', shortTime : true
          }).on('change', function(e, date)
          {
              $('#date-end').bootstrapMaterialDatePicker('setMinDate', date);
          });

          $('#min-date').bootstrapMaterialDatePicker({ format : 'DD/MM/YYYY HH:mm', minDate : new Date() });

          $.material.init()
      });
  </script>
<!--Wickedpicker-->
<script type="application/javascript">
   function shiftDateDiff(){
       var shiftD = document.getElementById("shiftDate").value;
       var ftime = document.getElementById("fromtime").value;
       var ttime = document.getElementById("totime").value;
       var tFTime = shiftD.concat(" ", ftime);
       var tTTime = shiftD.concat(" ", ttime);
       //tFTime = shiftD + " " + ftime;
       //tTTime = shiftDate + " " + ttime;
       var dFromTime = new Date(tFTime);
       var dToTime =  new Date(tTTime);
       var fHours = dFromTime.getHours();
       var fMinutes = dFromTime.getMinutes();
       var tHours = dToTime.getHours();
       var tMinutes = dToTime.getMinutes();

       var convFHourToMin = fHours*60;
       var convTHourToMin = tHours*60;

       var fromHourAndFromMin = convFHourToMin+fMinutes;
       var toHourAndToMin = convTHourToMin+tMinutes;
       var allMinutes = Math.abs(fromHourAndFromMin - toHourAndToMin);

       var finalHour = Math.floor(allMinutes/60);
       var  finalMinutes = allMinutes%60;
      var finalTime = finalHour.toString().concat(".",finalMinutes.toString());



       //var oneHour = 1000*60*60;
       //var vhours = Math.abs(fHours - tHours);
   // oneHour;
       //document.alert(dFromTime);
       document.getElementById("NoOfHours").value = finalTime;
        return false;
   }
</script>

</body>

</html>
