<?php
/**
 * Created by PhpStorm.
 * User: Forbes Diamond
 * Date: 2/12/2016
 * Time: 12:00 PM
 */
header("location:frontend/index.php");
?>